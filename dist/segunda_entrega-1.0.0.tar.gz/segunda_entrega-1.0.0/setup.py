from setuptools import setup

setup(
    name = "segunda_entrega",
    version = "1.0.0",
    description="Segunda entrega del curso de python",
    author="Kevin Ceron",
    author_email="kevmicesca@gmail.com",
    
    packages = ["paquete"]
)